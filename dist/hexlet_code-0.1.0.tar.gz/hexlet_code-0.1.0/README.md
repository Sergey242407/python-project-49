### Hexlet tests and linter status:
[![Actions Status](https://github.com/Sergey242407/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Sergey242407/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/ced6c049738d43d2b308/maintainability)](https://codeclimate.com/github/Sergey242407/python-project-49/maintainability)
[Asciinema brain-even](https://asciinema.org/connect/fb3966da-9b43-4869-9186-fc727bf4c7db)
[Asciinema brain-calc](https://asciinema.org/a/4PF7H6WK4fH4nRmJwstN9UaZp)
